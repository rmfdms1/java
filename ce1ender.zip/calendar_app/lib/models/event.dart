import 'package:intl/intl.dart';

class Event {
  final int? id;
  final String title;
  final String description;
  final DateTime startTime;
  final DateTime endTime;
  final String category;
  final bool isSpecialTime;
  final bool hasAlarm;
  final bool isCompleted;
  final bool isCancelled;

  Event({
    this.id,
    required this.title,
    required this.description,
    required this.startTime,
    required this.endTime,
    required this.category,
    this.isSpecialTime = false,
    this.hasAlarm = false,
    this.isCompleted = false,
    this.isCancelled = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'category': category,
      'isSpecialTime': isSpecialTime ? 1 : 0,
      'hasAlarm': hasAlarm ? 1 : 0,
      'isCompleted': isCompleted ? 1 : 0,
      'isCancelled': isCancelled ? 1 : 0,
    };
  }

  factory Event.fromMap(Map<String, dynamic> map) {
    return Event(
      id: map['id'],
      title: map['title'],
      description: map['description'],
      startTime: DateTime.parse(map['startTime']),
      endTime: DateTime.parse(map['endTime']),
      category: map['category'],
      isSpecialTime: map['isSpecialTime'] == 1,
      hasAlarm: map['hasAlarm'] == 1,
      isCompleted: map['isCompleted'] == 1,
      isCancelled: map['isCancelled'] == 1,
    );
  }

  String get formattedStartTime => DateFormat('HH:mm').format(startTime);
  String get formattedEndTime => DateFormat('HH:mm').format(endTime);
  String get formattedDate => DateFormat('yyyy-MM-dd').format(startTime);
} 