import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'schedule_dialog.dart';

// 공휴일 목록
final Set<DateTime> _holidays = {
  DateTime(2024, 1, 1),   // 신정
  DateTime(2024, 2, 9),   // 설날
  DateTime(2024, 2, 10),  // 설날
  DateTime(2024, 2, 11),  // 설날
  DateTime(2024, 2, 12),  // 대체공휴일
  DateTime(2024, 3, 1),   // 삼일절
  DateTime(2024, 4, 10),  // 국회의원선거일
  DateTime(2024, 5, 5),   // 어린이날
  DateTime(2024, 5, 6),   // 대체공휴일
  DateTime(2024, 5, 15),  // 부처님오신날
  DateTime(2024, 6, 6),   // 현충일
  DateTime(2024, 8, 15),  // 광복절
  DateTime(2024, 9, 16),  // 추석
  DateTime(2024, 9, 17),  // 추석
  DateTime(2024, 9, 18),  // 추석
  DateTime(2024, 10, 3),  // 개천절
  DateTime(2024, 10, 9),  // 한글날
  DateTime(2024, 12, 25), // 성탄절
};

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('ko_KR', null);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calendar App',
      theme: ThemeData(
        colorScheme: ColorScheme.light(
          primary: const Color(0xFFFF69B4), // 핑크
          secondary: const Color(0xFF40E0D0), // 민트
          background: Colors.white,
          surface: const Color(0xFFFFF0F5), // 연한 핑크 배경
          onPrimary: Colors.white,
          onSecondary: Colors.white,
        ),
        useMaterial3: true,
        cardTheme: CardTheme(
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          color: Colors.white,
        ),
        appBarTheme: const AppBarTheme(
          elevation: 0,
          centerTitle: true,
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          elevation: 4,
        ),
      ),
      home: const CalendarHomePage(),
    );
  }
}

class CalendarHomePage extends StatefulWidget {
  const CalendarHomePage({super.key});

  @override
  State<CalendarHomePage> createState() => _CalendarHomePageState();
}

class _CalendarHomePageState extends State<CalendarHomePage> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  Map<DateTime, List<Schedule>> _events = {};
  List<Schedule> _selectedDaySchedules = [];

  @override
  void initState() {
    super.initState();
    _selectedDay = _focusedDay;
    _updateSelectedDaySchedules();
  }

  void _updateSelectedDaySchedules() {
    final selected = DateTime(
      _selectedDay!.year,
      _selectedDay!.month,
      _selectedDay!.day,
    );
    _selectedDaySchedules = _events[selected] ?? [];
  }

  List<Schedule> _getAllSchedules() {
    List<Schedule> allSchedules = [];
    _events.forEach((_, schedules) {
      allSchedules.addAll(schedules);
    });
    // 시간순으로 정렬
    allSchedules.sort((a, b) => a.time.compareTo(b.time));
    return allSchedules;
  }

  void _addSchedule(Schedule schedule) {
    final date = DateTime(
      schedule.time.year,
      schedule.time.month,
      schedule.time.day,
    );
    setState(() {
      if (_events[date] == null) {
        _events[date] = [schedule];
      } else {
        _events[date]!.add(schedule);
      }
      _updateSelectedDaySchedules();
    });
  }

  void _toggleScheduleCompletion(Schedule schedule) {
    setState(() {
      schedule.isCompleted = !schedule.isCompleted;
      _updateSelectedDaySchedules();
    });
  }

  void _removeSchedule(Schedule schedule) {
    final date = DateTime(
      schedule.time.year,
      schedule.time.month,
      schedule.time.day,
    );
    setState(() {
      _events[date]?.remove(schedule);
      if (_events[date]?.isEmpty ?? false) {
        _events.remove(date);
      }
      _updateSelectedDaySchedules();
    });
  }

  Map<String, int> _getStatistics() {
    int completed = 0;
    int pending = 0;
    Set<String> categories = {};

    _events.forEach((_, schedules) {
      for (var schedule in schedules) {
        if (schedule.isCompleted) {
          completed++;
        } else {
          pending++;
        }
        categories.add(schedule.category);
      }
    });

    return {
      'completed': completed,
      'pending': pending,
      'success_rate': completed + pending > 0
          ? ((completed / (completed + pending)) * 100).round()
          : 0,
      'categories': categories.length,
    };
  }

  void _showStatistics() {
    final stats = _getStatistics();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('통계'),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        content: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildStatItem('완료된 일정', '${stats['completed']}개'),
              _buildStatItem('대기 중인 일정', '${stats['pending']}개'),
              _buildStatItem('성공률', '${stats['success_rate']}%'),
              _buildStatItem('카테고리 수', '${stats['categories']}개'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('닫기'),
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final allSchedules = _getAllSchedules();

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      appBar: AppBar(
        title: const Text('My Calendar'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.bar_chart),
            onPressed: _showStatistics,
          ),
        ],
      ),
      body: Column(
        children: [
          // Calendar Widget
          Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  spreadRadius: 2,
                  blurRadius: 5,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: TableCalendar(
              firstDay: DateTime.utc(2024, 1, 1),
              lastDay: DateTime.utc(2025, 12, 31),
              focusedDay: _focusedDay,
              calendarFormat: _calendarFormat,
              selectedDayPredicate: (day) {
                return isSameDay(_selectedDay, day);
              },
              onDaySelected: (selectedDay, focusedDay) {
                setState(() {
                  _selectedDay = selectedDay;
                  _focusedDay = focusedDay;
                  _updateSelectedDaySchedules();
                });
              },
              onFormatChanged: (format) {
                setState(() {
                  _calendarFormat = format;
                });
              },
              eventLoader: (day) {
                return _events[day] ?? [];
              },
              calendarStyle: CalendarStyle(
                selectedDecoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primary,
                  shape: BoxShape.circle,
                ),
                todayDecoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.secondary.withOpacity(0.3),
                  shape: BoxShape.circle,
                ),
                markerDecoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.secondary,
                  shape: BoxShape.circle,
                ),
                holidayDecoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                holidayTextStyle: const TextStyle(color: Colors.red),
                weekendTextStyle: const TextStyle(color: Colors.red),
              ),
              calendarBuilders: CalendarBuilders(
                markerBuilder: (context, date, events) {
                  if (events.isEmpty) return null;
                  return Positioned(
                    bottom: 1,
                    child: Container(
                      height: 2,
                      width: 30,
                      color: Theme.of(context).colorScheme.secondary,
                    ),
                  );
                },
                dowBuilder: (context, day) {
                  if (day.weekday == DateTime.sunday) {
                    return Center(
                      child: Text(
                        DateFormat.E('ko_KR').format(day),
                        style: const TextStyle(color: Colors.red),
                      ),
                    );
                  }
                  return null;
                },
              ),
              holidayPredicate: (day) {
                return _holidays.any((holiday) =>
                    holiday.year == day.year &&
                    holiday.month == day.month &&
                    holiday.day == day.day);
              },
              headerStyle: HeaderStyle(
                formatButtonVisible: false,
                titleCentered: true,
                leftChevronIcon: Icon(
                  Icons.chevron_left,
                  color: Theme.of(context).colorScheme.primary,
                ),
                rightChevronIcon: Icon(
                  Icons.chevron_right,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
            ),
          ),
          
          // 전체 일정 목록
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '전체 일정',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: ListView.builder(
                      itemCount: allSchedules.length,
                      itemBuilder: (context, index) {
                        final schedule = allSchedules[index];
                        return Card(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: ListTile(
                            leading: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.secondary.withOpacity(0.2),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                Icons.event,
                                color: Theme.of(context).colorScheme.secondary,
                              ),
                            ),
                            title: Text(
                              schedule.title,
                              style: TextStyle(
                                decoration: schedule.isCompleted
                                    ? TextDecoration.lineThrough
                                    : null,
                                color: schedule.isCompleted
                                    ? Colors.grey
                                    : Colors.black87,
                              ),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('날짜: ${DateFormat('yyyy-MM-dd').format(schedule.time)}'),
                                Text('시간: ${DateFormat('HH:mm').format(schedule.time)}'),
                                Text('카테고리: ${schedule.category}'),
                                if (schedule.hasAlarm && schedule.alarmTime != null)
                                  Text('알람: ${DateFormat('HH:mm').format(schedule.alarmTime!)}'),
                              ],
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: Icon(
                                    schedule.isCompleted
                                        ? Icons.check_circle
                                        : Icons.check_circle_outline,
                                    color: schedule.isCompleted
                                        ? Colors.green
                                        : Theme.of(context).colorScheme.secondary,
                                  ),
                                  onPressed: () => _toggleScheduleCompletion(schedule),
                                ),
                                IconButton(
                                  icon: Icon(
                                    Icons.cancel_outlined,
                                    color: Theme.of(context).colorScheme.primary,
                                  ),
                                  onPressed: () => _removeSchedule(schedule),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          // 선택한 날짜의 일정
          Container(
            height: 200,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  spreadRadius: 2,
                  blurRadius: 5,
                  offset: const Offset(0, -3),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${DateFormat('yyyy년 MM월 dd일').format(_selectedDay!)} 일정',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: Theme.of(context).colorScheme.primary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: ListView.builder(
                    itemCount: _selectedDaySchedules.length,
                    itemBuilder: (context, index) {
                      final schedule = _selectedDaySchedules[index];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 4),
                        child: ListTile(
                          title: Text(
                            schedule.title,
                            style: TextStyle(
                              decoration: schedule.isCompleted
                                  ? TextDecoration.lineThrough
                                  : null,
                              color: schedule.isCompleted
                                  ? Colors.grey
                                  : Colors.black87,
                            ),
                          ),
                          subtitle: Text('${DateFormat('HH:mm').format(schedule.time)} - ${schedule.category}'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: Icon(
                                  schedule.isCompleted
                                      ? Icons.check_circle
                                      : Icons.check_circle_outline,
                                  color: schedule.isCompleted
                                      ? Colors.green
                                      : Theme.of(context).colorScheme.secondary,
                                ),
                                onPressed: () => _toggleScheduleCompletion(schedule),
                              ),
                              IconButton(
                                icon: Icon(
                                  Icons.cancel_outlined,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                                onPressed: () => _removeSchedule(schedule),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await showDialog<Map<String, dynamic>>(
            context: context,
            builder: (context) => ScheduleDialog(selectedDate: _selectedDay!),
          );

          if (result != null) {
            _addSchedule(Schedule(
              title: result['title'],
              time: result['time'],
              category: result['category'],
              hasAlarm: result['hasAlarm'],
              alarmTime: result['alarmTime'],
            ));
          }
        },
        backgroundColor: Theme.of(context).colorScheme.primary,
        child: const Icon(Icons.add),
      ),
    );
  }
}

class Schedule {
  final String title;
  final DateTime time;
  final String category;
  final bool hasAlarm;
  final DateTime? alarmTime;
  bool isCompleted;

  Schedule({
    required this.title,
    required this.time,
    required this.category,
    this.hasAlarm = false,
    this.alarmTime,
    this.isCompleted = false,
  });
}
