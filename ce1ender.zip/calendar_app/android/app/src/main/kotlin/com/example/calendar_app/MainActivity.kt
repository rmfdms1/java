package com.example.calendar_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
