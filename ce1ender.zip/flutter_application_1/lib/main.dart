import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      title: '핑크 캘린더',
      theme: pinkTheme,
      home: CalendarHomePage(),
    ),
  );
}
ThemeData pinkTheme = ThemeData(
  scaffoldBackgroundColor: Colors.pink[50],
  floatingActionButtonTheme: FloatingActionButtonThemeData(
    backgroundColor: Colors.pink,
  ), colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.pink).copyWith(secondary: Colors.pinkAccent),
);

class CalendarHomePage extends StatelessWidget {
  const CalendarHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('핑크 캘린더')),
      body: Column(
        children: [
          TableCalendar(
            // ...달력 세팅
          ),
          Expanded(
            child: ScheduleListView(), // 선택 날짜의 일정 리스트
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // 일정 추가 페이지로 이동
        },
        child: Icon(Icons.add),
      ),
    );
  }
}